This directory contains *non-free* WLAN firmware that GNU/Linux might require you to
provide when seting up Wireless access on the Raspberry Pi 4. For instance, Debian 11
may ask you to provide these files during installation.

These files were extracted from:
https://archive.raspberrypi.org/debian/pool/main/f/firmware-nonfree/firmware-brcm80211_20190114-1+rpt11_all.deb

The Bluetooth module may also require firmware from:
https://github.com/RPi-Distro/bluez-firmware/tree/master/broadcom
